// General utility functions for the e-commerce site

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            if (alert && alert.parentNode) {
                alert.classList.add('fade');
                setTimeout(function() {
                    if (alert.parentNode) {
                        alert.parentNode.removeChild(alert);
                    }
                }, 500);
            }
        });
    }, 5000);

    // Add animation to cart buttons
    const addToCartButtons = document.querySelectorAll('form button[type="submit"]');
    addToCartButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            this.classList.add('btn-success');
            this.textContent = 'Added!';
            setTimeout(() => {
                if (this.classList.contains('btn-success')) {
                    this.classList.remove('btn-success');
                    this.textContent = 'Add to Cart';
                }
            }, 1500);
        });
    });

    // Quantity input validation for cart
    const quantityInputs = document.querySelectorAll('input[type="number"][name="quantity"]');
    quantityInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            if (this.value < 1) {
                this.value = 1;
            }
        });
    });
});