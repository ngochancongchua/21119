from django.db import models

# Core models will be implemented as needed